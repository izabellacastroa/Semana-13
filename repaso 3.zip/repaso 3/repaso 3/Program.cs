﻿using System;

public class Texto
{
    public string Text { get; set; }
    public int Number { get; set; }
}

public class AnalizadorTexto
{
    public int ContarPalabras(string texto)
    {
        // Implementación para contar palabras
        string[] palabras = texto.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        return palabras.Length;
    }

    public string ObtenerPalabraMasLarga(string texto)
    {
        // Implementación para obtener la palabra más larga
        string[] palabras = texto.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        string palabraMasLarga = "";
        foreach (string palabra in palabras)
        {
            if (palabra.Length > palabraMasLarga.Length)
            {
                palabraMasLarga = palabra;
            }
        }
        return palabraMasLarga;
    }
}

public class ProgramaPrincipal
{
    static void Main(string[] args)
    {
        Texto[] textos = new Texto[300];
        AnalizadorTexto analizador = new AnalizadorTexto();

        int contador = 0;
        string respuesta = "si";

        while (contador < 300 && respuesta.ToLower() == "si")
        {
            Console.WriteLine("Ingrese una oración:");
            string oracion = Console.ReadLine();

            // Recortar el texto si excede los 300 caracteres
            if (oracion.Length > 300)
            {
                oracion = oracion.Substring(0, 300);
            }

            // Eliminar espacios en blanco al inicio y al final del texto
            oracion = oracion.Trim();

            // Crear instancia de la clase Texto y asignar el texto ingresado
            Texto texto = new Texto();
            texto.Text = oracion;

            // Contar palabras y obtener la palabra más larga
            texto.Number = analizador.ContarPalabras(oracion);
            string palabraMasLarga = analizador.ObtenerPalabraMasLarga(oracion);

            // Almacenar el resultado en el array
            textos[contador] = texto;

            contador++;

            Console.WriteLine("¿Desea ingresar otra oración? (si/no)");
            respuesta = Console.ReadLine();
        }

        // Calcular el promedio de palabras en cada oración
        int totalPalabras = 0;
        foreach (Texto texto in textos)
        {
            totalPalabras += texto.Number;
        }
        double promedioPalabras = (double)totalPalabras / contador;

        // Encontrar la palabra más larga de todas las oraciones
        string palabraMasLargaGlobal = "";
        foreach (Texto texto in textos)
        {
            if (texto.Text != null)
            {
                string palabraMasLarga = analizador.ObtenerPalabraMasLarga(texto.Text);
                if (palabraMasLarga.Length > palabraMasLargaGlobal.Length)
                {
                    palabraMasLargaGlobal = palabraMasLarga;
                }
            }
        }

        Console.WriteLine("Promedio de palabras por oración: " + promedioPalabras);
        Console.WriteLine("Palabra más larga de todas las oraciones: " + palabraMasLargaGlobal);
    }
}

